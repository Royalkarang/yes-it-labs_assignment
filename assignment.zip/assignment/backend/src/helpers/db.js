import mongoose from "mongoose";

const DB = async () => {
    try {
        const connection = await mongoose.connect(process.env.MONGO_URI);
        console.log("DB connected successfully :-", connection.connection.host);
    } catch (error) {
        console.log("DB Connect Failed", error);
        process.exit(1);
    }
}

export { DB}