import jwt from 'jsonwebtoken';

const verifyJWT = async (req, res, next) => {
  try {
    const token =
      req.cookies?.authToken ||
      req.header("Authorization")?.replace("Bearer ", "");

    if (!token) {
      return res.status(401).json({ message: "Unauthorized request" });
    }

    const decoded = await jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    console.error("Error authenticating token", error);
    return res.status(401).json({ message: "Invalid or expired token" });
  }
};

export default verifyJWT;
