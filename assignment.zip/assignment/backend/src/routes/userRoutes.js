import { Router } from "express";
import verifyJWT from "../middleware/auth.middleware.js";
import { deleteUser, forgetPassword, loginUser, registerUser, resetPassword,
  updateUser, } from "../controllers/userController.js";

const userRoute = Router();

userRoute.post("/register", registerUser);
userRoute.post("/login", loginUser);
userRoute.put("/updateUser", updateUser);
userRoute.post("/forgetPassword", forgetPassword);
userRoute.patch("/resetPassword/:token", resetPassword);
userRoute.delete("/deleteUser", verifyJWT, deleteUser);

export default userRoute;
