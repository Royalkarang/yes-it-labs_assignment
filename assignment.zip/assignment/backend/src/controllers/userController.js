import sendEmail from "../helpers/nodeMailer.js";
import User from "../schema/userSchema.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

const registerUser = async (req, res) => {
  const { name, email, username, password, phone } = req.body;

  // Validate the input
  if (!name || !email || !username || !password) {
    return res.status(400).json({ message: "All fields are required." });
  }

  // check user exists
  const exisingUser = await User.findOne({ $or: [{ email }, { username }] });

  if (exisingUser) {
    return res.status(400).send({ message: "User already exists." });
  }

  const passwordRegex =
    /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=.*[^\w\d\s]).{6,}$/;

  if (!passwordRegex.test(password)) {
    return res.status(400).json({
      message:
        "Password must be at least 6 characters long, contain at least one uppercase letter, one lowercase letter, one number, and one special character.",
    });
  }

  // Create a new user
  const newUser = new User({
    name,
    email,
    username,
    password,
    phone
  });

  // Password Hashing
  newUser.password = await bcrypt.hash(password, 10);

  // Save the user to the database
  await newUser.save();

  res.status(201).json({ message: "User registered successfully." });
};

const loginUser = async (req, res) => {
  const { username, email, password } = req.body;

  // Validate the input
  if (!(username || email) || !password) {
    return res
      .status(400)
      .json({ message: "Username or email and password are required." });
  }

  const existsUser = await User.findOne(
    { $or: [{ email }, { username }] },
    { password: true }
  );

  if (!existsUser) {
    return res.status(401).json({ message: "Invalid username or email." });
  }

  const isMatch = await bcrypt.compare(password, existsUser.password);

  if (!isMatch) {
    return res.status(401).json({ message: "Invalid password." });
  }

  // Generate JWT
  const token = jwt.sign(
    { id: existsUser._id, username: existsUser.username },
    process.env.JWT_SECRET,
    { expiresIn: "1d" }
  );
  res.cookie("authToken", token);

  res.status(200).json({ message: "User logged in successfully.", token });
};

const updateUser = async (req, res) => {
  const { name, username, email } = req.body;

  if (!(username || name) || !email) {
    return res.status(400).json({ message: "Username or name and email are required." });
  }

  try {
    // Find the user by email
    const existsUser = await User.findOne({ email });

    if (!existsUser) {
      return res.status(401).json({ message: "Invalid username or email." });
    }

    // Update user details
    if (name) existsUser.name = name;
    if (username) existsUser.username = username;

    await existsUser.save();

    return res.status(200).json({ message: "User updated successfully", user: existsUser });

  } catch (error) {
    console.error("Error updating user:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const forgetPassword = async (req, res) => {
  try {
    const { email, username } = req.body;

    if (!(email || username)) {
      return res
        .status(400)
        .json({ message: "Email or username are required." });
    }

    const existingUser = await User.findOne({ $or: [{ email }, { username }] });

    if (!existingUser) {
      return res.status(401).json({ message: "User not found." });
    }

    const token = jwt.sign(
      { id: existingUser._id, username: existingUser.username },
      process.env.JWT_SECRET,
      { expiresIn: "5m" }
    );

    const resetLink = `http://localhost:8800/api/v1/resetPassword/${token}`;

    const emailFormat = `
        <h2>Password Reset Request</h2>
        <p>You have requested to reset your password.</p>
        <p>click to reset your password ${resetLink}</p>
        <p>If you did not request this, you can safely ignore this email.</p>
        <p>Thank you,</p>
    `;

    // Send OTP via email
    sendEmail(existingUser.email, "Forgot password (Revision)", emailFormat);

    res
      .status(200)
      .json({ message: "OTP sent successfully. check your Email..." });
  } catch (error) {
    console.log(error, "Error in Forget password");
  }
};

const resetPassword = async (req, res) => {
  const { password, confirmPassword } = req.body;
  const { token } = req.params;

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // Find the user based on the decoded email
    const existingUser = await User.findOne({ username: decoded.username });
    if (!existingUser) {
      return res.status(400).json({ message: "Unauthorized request" });
    }

    // Check if password and confirmPassword match
    if (password !== confirmPassword) {
      return res
        .status(400)
        .json({ message: "Password and confirm password do not match" });
    }

    // Hash the new password
    const hashedPassword = await bcrypt.hash(password, 9);

    // Update the user's password
    existingUser.password = hashedPassword;
    await existingUser.save(); // Ensure save is awaited

    return res.status(200).json({ message: "Password reset successfully" });
  } catch (error) {
    console.error("Error resetting password:", error);
    return res.status(500).json({ message: "Internal server error" });
  }
};

const deleteUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email && !password) {
      return res.status(400).json("Email and password are required");
    }

    const existingUser = await User.findOne({ email });
    if (!existingUser) {
      return res.status(400).json("User not Found");
    }

    const matchPassword = bcrypt.compare(password, existingUser.password);
    if (!matchPassword) {
      res.status(500).json("Something went wrong or wrong password");
    }

    await User.findByIdAndDelete(existingUser._id);
    return res.status(200).json("User Deleted Sucessfully");
  } catch (error) {
    console.log("error in delete User", error);
  }
};

export { registerUser, loginUser, updateUser, forgetPassword, resetPassword, deleteUser };
