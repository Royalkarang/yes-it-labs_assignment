import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { toast } from "react-toastify";
import axios from "axios";

const baseURL= `http://localhost:8800/api/v1` 


export const registerUser = createAsyncThunk("auth/registerUser", async (formData, { rejectWithValue }) => {
    try {
      const response = await axios.post(`${baseURL}/register`, formData)
      return response.data
    } catch (error) {
      const errorMessage =
        error.response?.data?.message || error.message || "Something went wrong";
      return rejectWithValue(errorMessage);
    }
  }
);

const authSlice = createSlice({
  name: "auth",
  initialState: {
    user: null,
    loading: false,
    error: null,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(registerUser.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(registerUser.fulfilled, (state, action) => {
        state.loading = false;
        state.user = action.payload;
        toast.success(action.payload.message || "Registration successful!");
      })
      .addCase(registerUser.rejected, (state, action) => {
        state.loading = false;
        state.user = null;
        state.error = action.payload || "Failed to register user";
        toast.error(action.payload || "Failed to register user");
      });
  },
});

export default authSlice.reducer;
