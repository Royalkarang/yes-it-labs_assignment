import React from 'react';
import { useForm } from 'react-hook-form';
import { useDispatch } from 'react-redux';
import { registerUser } from './redux/slices/authSlice.js';


const Form = () => {
  const dispatch = useDispatch();
  const { register, handleSubmit, formState: { errors } } = useForm();

  function validatePhoneNumber(phoneNumber) {
    const phoneNumberRegex = /^[6-9]\d{9}$/;
    return phoneNumberRegex.test(phoneNumber) || 'Invalid phone number';
  }

  const onSubmit = (data) => {
    console.log(data)
    dispatch(registerUser(data))
  };

  return (
    <div className="max-w-md mx-auto p-4 bg-white shadow-lg rounded-lg">
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
        <h1 className='text-center font-bold text-3xl'> Signup </h1>
        
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-700">Name</label>
          <input id="name"  type="text" placeholder='Eg:- Royal Singh' {...register('name', { required: 'Name is required' })}
            className="w-full mt-2 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500" />
          {errors.name && <span className="text-red-500 text-xs">{errors.name.message}</span>}
        </div>
        
        <div>
          <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email</label>
          <input id="email" type="email" placeholder='Eg:- example@gmail.com' {...register('email', { 
              required: 'Email is required', 
              pattern: { value: /^[^@]+@[^@]+\.[^@]+$/, message: 'Invalid email address' }
            })}
            className="w-full mt-2 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          {errors.email && <span className="text-red-500 text-xs">{errors.email.message}</span>}
        </div>

        <div>
          <label htmlFor="username" className="block text-sm font-medium text-gray-700"> Username </label>
          <input id="username" type="text" placeholder='Eg:- Trial1112' {...register('username', { 
              required: 'username is required', })}
            className="w-full mt-2 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          {errors.username && <span className="text-red-500 text-xs">{errors.username.message}</span>}
        </div>
        
        <div>
          <label htmlFor="phone" className="block text-sm font-medium text-gray-700">Phone Number</label>
          <input id="phone" type="text" placeholder='Eg:- 7182937182' {...register('phone', { required: 'Phone Number is required',
            validate: validatePhoneNumber })} className="w-full mt-2 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500" />
          {errors.phone && <span className="text-red-500 text-xs">{errors.phone.message}</span>}
        </div>

        <div>
          <label htmlFor="password" className="block text-sm font-medium text-gray-700">Password</label>
          <input id="password" type="password" placeholder='Eg:- atleast 6 characters, uppercase, lowercase, symbol, number' {...register('password', { required: 'Password is required' })}
            className="w-full mt-2 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500" />
          {errors.password && <span className="text-red-500 text-xs">{errors.password.message}</span>}
        </div>

        <div className="flex justify-center">
          <button type="submit" className="w-full py-2 mt-4 bg-blue-500 text-white rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500" >
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};

export default Form;
