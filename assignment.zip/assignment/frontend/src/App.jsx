import React from 'react'
import { Provider } from 'react-redux'
import store from './redux/store.js'
import Form from './Form.jsx'
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const App = () => {
  return (
    <Provider store={store}>
      <Form />
      <ToastContainer />
    </Provider>
  )
}

export default App
